var monkey;
var ground;
var bananasGroup;
var obstacleGroup;
var Bananas;
var Obstacle;
var farmland;
var score = 0;

function preload() {
  monkeyImage = loadImage("Monkey_01.png");
  BananasImage = loadImage("banana.png");
  ObstacleImage = loadImage("stone.png");
  farmlandImage = loadImage("jungle.jpg");
  
}
  
  


function setup() {
  createCanvas(400, 400);
  farmland = createSprite(200,200,1000,1000);
 farmland.setAnimation("farm_land_1");
 monkey = createSprite(50,345,20,50);
 monkey.setAnimation("monkey");
 monkey.scale = 0.15;
 monkey.debug = true;
 ground = createSprite(200,395,1000,20);
 
  BananasGroup = createGroup();
  ObstacleGroup = createGroup();
}

function draw() {
  background("jungle.jpg");
  if(keyDown("space")&& monkey.y>=250) {
    monkey.velocityY = -15;
  }
  monkey.velocityY = monkey.velocityY + 0.8;
  
    ground.velocityX = -6;
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  
  if(monkey.isTouching(bananasGroup)) {
    score = score+1;
    bananasGroup.destroyEach();
  }
  
  if(monkey.isTouching(obstacleGroup)){
    monkey.scale = 0.15;
    score = 0;
  }
  
  switch(score) {
    case 10: monkey.scale = 0.20;
    break;
    case 20: monkey.scale = 0.25;
    break;
    case 30: monkey.scale = 0.30;
    break;
    case 40: monkey.scale = 0.35;
    break;
    case 50: monkey.scale = 0.40;
    break;
    default: break;
    //case 
    }

console.log(monkey.y); 
monkey.collide(ground); 
  
spawnBananas();
spawnObstacle();
  
drawSprites();
}

function spawnBananas() {
  if(World.frameCount % 80 === 0){
   Bananas = createSprite(400,300,5,5);
   Bananas.y = randomNumber(250,300);
   Bananas.velocityX = -6;
   Bananas.addAnimation("Banana");
   Bananas.scale = 0.05;
   Bananas.lifetime = 170;
   Bananas.debug = true; 
   bananasGroup.add(Bananas);
  }
}

function spawnObstacle() {
  if(World.frameCount % 300 === 0){
    Obstacle = createSprite(400,350,10,10);
    Obstacle.addAnimation("Stone");
    Obstacle.scale = 0.2;
    Obstacle.velocityX = -6;
    obstacleGroup.add(Obstacle);
  }
}


